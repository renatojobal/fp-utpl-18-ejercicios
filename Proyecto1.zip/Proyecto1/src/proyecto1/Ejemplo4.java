/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author Renato
 */
public class Ejemplo4 {
    public static void main(String[] args){
        String nombre = "Renato";
        String apellido = "Balcázar";
        int edad = 18;
        double valor = 40;
        
        // System.out.println(mensaje1+"\n"+mensaje2);
        System.out.printf("%s %s\n\tEdad:%d\n\tValor:%.1f\n",nombre,apellido,edad,valor);
    
    }
            
}
